import styled from 'styled-components';

const HeaderClass = styled.div `
background: rgba(46,50,53,0.9);
position: absolute;
width: 100%;
z-index: 10;
height:74px;
`;

export default HeaderClass;
