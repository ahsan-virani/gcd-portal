import styled from 'styled-components';

const LogoClass = styled.div `
float: left;
width: 305px;
padding: 23px 0;
`;

export default LogoClass;
