import styled from 'styled-components';

export default styled.div `
      float: right;
      margin: 32px 0 0;
      width: 70%;
      height: 43px;
`;
