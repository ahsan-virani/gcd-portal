import styled from 'styled-components';

const WrapperClass = styled.div `
      
      margin: 0 auto;
      width: 1180px;
`;

export default WrapperClass;
