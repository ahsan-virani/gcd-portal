import styled from 'styled-components';

const Ul = styled.ul `
  text-align: right;
`;

export default Ul;
